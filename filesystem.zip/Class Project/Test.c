#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <string.h>


void usage()
{
	//Describes the usage/help summary for the program.

	printf("A program used for searching filesystems.\n");
	printf("Usage Summary:\n");
	printf("	-h: Help options\n");
	printf("	-f: File or fragment to open\n");
	printf("	-a: Search accuracy\n");
}

int main (int argc, char *argv[])
{
	int y = 0;
	int i = 0;
	int ii = 0;
	int opt = 0; 			//options menu
	double accuracy = 90;	//The accuracy in %form
	int type;				//Type of file to search for
	double acc;   			//How many bytes we can get wrong.
	double tempacc;			//A temp value to count how many error bytes we have left
	long len;				//Length of file
	long fileplc;			//File place
	char j;				//Current character from given file
	char k;				//Current character from file in current comparison
	long tempplace;			//Holds the file place for backwards iterations
	char *filename;
	char *tempfilename;		//Holds the name of the current comparrison file.
	FILE *fptr = NULL;		//The given file
	FILE *tempfile = NULL;	//The current comparrison file
	DIR *d;
	struct dirent *dir;
	

	//Options menu
	opt = getopt( argc, argv,"ht:f:a:" );
	//Options Menu
	while (opt != -1)
	{
		switch (opt)
		{
			case 'h':
                		usage();
                		return 0;

			case 't':
					type = atoi(optarg);

			case 'f':
					filename = optarg;
					if((fptr = fopen(filename, "rb")) == NULL)
					{
						printf("Error opening given file!\n");
						return 0;
					}


			case 'a':
					accuracy = atoi(optarg);
				


		}

		opt = getopt( argc, argv, "ht:f:a:" );
	}
	

	accuracy = 100-accuracy;				//Inverses the accuracy to see what percent of the file we can get wrong
	fseek(fptr, 0, SEEK_END);				//Finds the end
	len = ftell(fptr);						//Then records the length of the given file
	printf("Filesize is: %ld\n", len);		//Prints filesize
	rewind(fptr);							//Go back to start
	acc = trunc((accuracy/100)*len);		//Records the number of bytes we can miss
	printf("Acc is: %lf\n", acc);


	//Opens working directory
	d = opendir(".");
	if (d)
	{
		while ((dir = readdir(d)) != NULL) 									//Loops through directory
		{
      		//printf("%s\n", dir->d_name);
      		tempfilename = dir->d_name;										//Our tempfile is the next file in the directory
      		if((tempfile = fopen(tempfilename, "rb")) == NULL)				//Open tempfile
				printf("Error opening test!");								
			if(strcmp(filename, tempfilename) && dir->d_type != DT_DIR)		//See if it's our given file, or if it's a directory. If not, we proceed.
			{


				//Here's where the comparison starts.
				for(ii = 0; ii < len-acc; ii++)
				{
					//printf("\n\nNew It 1\n\n");
					rewind(fptr);
					fseek(fptr, ii, SEEK_SET);
					do 
					{
						//printf("\n\nNew It 2\n\n");
						tempplace = ftell(tempfile);				//Hold the current position of our tempfile
						tempacc = acc - ii;
						for(i = 0; i < len; i++)
						{
							j = fgetc(fptr);
							k = fgetc(tempfile);

							if (j != k)
							{
								tempacc--;
								if(j == '\n')
									j = ';';
								if(k == '\n')
									k = ';';
								fileplc = ftell(fptr);
								//printf("Character number: %ld       \t", fileplc);
								//printf("%c     %c         Error room left: %lf\n", j, k, tempacc);
				
							}

							if(tempacc <= 0 || feof(tempfile))
								break;
						}
					
						if(feof(tempfile))
							break;
						if(tempacc > 0)
						{
							y = 1;
							break;
						}
					
						rewind(fptr);
						fseek(fptr, ii, SEEK_SET);
						fseek(tempfile, (tempplace + 1), SEEK_SET);
					}while(!feof(tempfile));

					if(tempacc > 0 && y)
					{
						printf("\n\nFragment match found!\nFile in %s has accuracy of %lf%%\n", tempfilename, ((len - (acc - tempacc))/len*100));
						rewind(tempfile);
						fseek(tempfile, (tempplace), SEEK_SET);
						fileplc = ftell(tempfile);
						printf("File position on match is: %ld\n", fileplc);
						printf("Starting at text matching: ");
						for(y = 0; y < acc; y++)
						{
							k = fgetc(tempfile);
							printf("%c", k);
						}
						printf("\n");
						break;
					}
					if(tempacc <= 0)
						break;
					rewind(tempfile);

				}


			}
			fclose(tempfile);
			//return 0;
		}
	closedir(d);
	}

	fclose(fptr);
	return 0;
}